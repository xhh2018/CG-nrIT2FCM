function [I,data,samples] = MreadT2()

clear all;
close all;
clc;

I=imread('dc.tif');

[imageWidth,imageHeight,samples] = size(I);
figure,

imshow(I(:,:,1:3));

sampleSet=zeros(imageWidth,imageHeight,samples);
sampleSet=I;
A = zeros(imageWidth*imageHeight,samples);


for m=1:samples 
  A(:,m) = reshape(sampleSet (:,:,m),imageWidth*imageHeight,1);

end

data=A;
