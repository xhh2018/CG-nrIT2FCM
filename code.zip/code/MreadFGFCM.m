% imread data  Function for nrIT2FCM(nr-IT2FCM)
function [I,data,samples] = MreadFGFCM()

I=imread('dc.tif');

I1=I;
figure,
imshow(I1(:,:,1:3));
[imageWidth,imageHeight,samples] = size(I1);

I2=zeros(imageWidth,imageHeight,samples);
n=5; % filter windows 5*5
for sam=1:samples
 [height, width] = size(I1(:,:,sam));  
x1 = double(I1(:,:,sam)); 
x2 = x1; 
% dsij=[8 5 4 5 8;5 2 1 2 5;4 1 0 1 4; 5 2 1 2 5;8 5 4 5 8];% ���������õľ���
dsij=[2 2 2 2 2;2 1 1 1 2;2 1 0 1 2; 2 1 1 1 2;2 2 2 2 2];% FGFCM�������õľ���
ssij=exp(-sqrt(dsij)/30);
for i = 1:height-n+1  
    for j = 1:width-n+1  
         c = x1(i:i+n-1,j:j+n-1); 
        dxij=x1(i:i+n-1,j:j+n-1)-x1(i+n-3,j+n-3); 
        dxij2=dxij.^2;
        gg=sum(sum(dxij2))/24;
        if gg==0
          sgij=0;
        else
          sgij=exp(-dxij2/gg);
        end
        sij=ssij.*sgij;
        x2(i+(n-1)/2,j+(n-1)/2) =sum(sij.*c)/sum(sij);
    end  
end  
 I2(:,:,sam)=x2;

end

sampleSet1=zeros(imageWidth,imageHeight,samples);
sampleSet1=I1;
A1 = zeros(imageWidth*imageHeight,samples);

sampleSet2=zeros(imageWidth,imageHeight,samples);
sampleSet2=I2;
A2 = zeros(imageWidth*imageHeight,samples);


for m=1:samples  
  A1(:,m) = reshape(sampleSet1(:,:,m),imageWidth*imageHeight,1);
  A2(:,m) = reshape(sampleSet2(:,:,m),imageWidth*imageHeight,1);
end
data=A2;
% data1=A1;  
% data2=A2;  
