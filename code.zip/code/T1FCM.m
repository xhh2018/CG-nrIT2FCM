 function [ result,ve,mm,dlist ] = T1FCM( x,vs,dis,r) 
e=1e-5;
L=10;
l=1;
dlist=zeros(L,1);
import IT2FCM.*;
v1=vs; %  vs=rand(cluster_num,sam)*255
while(l<=L)  
    mm=Utility.MembershipMatrix(v1,x,dis,r);
    v2=Utility.GetCenter(x,mm,r);
   
    dtmp=Distances.Euclidean(v1,v2);  
    dlist(l)=dtmp;
    if(dtmp<e) 
        break;
    else
        v1=v2;
        l=l+1;   
    end
end
ve=v2;
result=HardPartition(ve,x,dis);


