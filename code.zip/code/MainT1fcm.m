% Main Function of T1FCM

[I,data] = MreadT1(); 

[m,n,sam] = size(I);

cluster_num=5; 

[t2t,t2v,v,dlist] =T1FCM(data,rand(cluster_num,sam)*255,'Euclidean',2);

B2=zeros(m,n); 
B2(:,:) =abs(reshape(t2t(:,1),m,n));

clims = [ 1 cluster_num ];
figure,imagesc(B2,clims);
colormap(jet)
figure,imshow(B2,[1 cluster_num]);
conNUM=3;

map2=zeros(cluster_num,conNUM);
for i=1:cluster_num
    for j=1:conNUM
    map2(i,j)=i/(1.0*cluster_num);
    end
end
colormap(map2);
imwrite(B2,map2,'T1result.bmp');
