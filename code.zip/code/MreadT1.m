% read image data
function [I,data,samples] = MreadT1()

clear all;
close all;
clc;

I=imread('dc.tif');

[imageWidth,imageHeight,samples] = size(I);
figure,


 imshow(I);

sampleSet=zeros(imageWidth,imageHeight,samples);
sampleSet=I;
A = zeros(imageWidth*imageHeight,samples);

for m=1:samples 
  A(:,m) = reshape(sampleSet (:,:,m),imageWidth*imageHeight,1);

end

data=A;
