% nr-IT2FCM (3 An interval type-2 fuzzy sets generation method based on neighborhood information)
% Main Function of nrIT2FCM(nr-IT2FCM)
clc
close all

[I,data,data1,data2] = Mreadnr(); 
[m,n,sam] = size(I);

cluster_num=10; 

[t2t,t2v,vl,vr,dlist] = nrIT2FCM.Method2(data,data1,data2,rand(cluster_num,sam)*255,'euclidean',2,2,3);
 
B2=zeros(m,n);
B2(:,:) =abs(reshape(t2t(:,1),m,n));

clims = [ 1 cluster_num ];
figure,imagesc(B2,clims);
colormap(jet)
figure,imshow(B2,[1 cluster_num]);

conNUM=3;

map2=zeros(cluster_num,conNUM);
for i=1:cluster_num
    for j=1:conNUM
    map2(i,j)=i/(1.0*cluster_num);
    end
end
colormap(map2);

imwrite(B2,map2,'nrIT2FCMresult.bmp');

